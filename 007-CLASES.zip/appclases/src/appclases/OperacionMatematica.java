package appclases;

public class OperacionMatematica
{
	public float Operar(int x, int y, String tipoOperacion)
	{
		float resultado=0;
		
		switch(tipoOperacion)
		{
			case "suma":
				resultado=x+y;
				break;
			case "resta":
				resultado=x-y;
				break;
			case "multiplicacion":
				resultado=x*y;
				break;
			case "division":
				resultado=((float)x)/((float)y);
				break;
				
			default:
				System.out.println("El tipo de operaci�n especificada no existe.");
				break;
		}
		
		return resultado;
	}
	
	public void Hola()
	{
		System.out.println("Hola desde enlawebdekaaf.blogspot.com");
	}
}