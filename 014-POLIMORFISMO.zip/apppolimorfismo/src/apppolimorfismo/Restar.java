package apppolimorfismo;

public class Restar extends Operacion
{
	public int operar(int x, int y)
	{
		return x-y;
	}
}