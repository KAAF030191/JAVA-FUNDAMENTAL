package appconstructores;

public class Persona
{
	private String nombre;
	
	public Persona()
	{
		this.nombre="persona desconocida";
	}
	
	public Persona(String nombre)
	{
		this.nombre=nombre;
	}
	
	public void Saludar()
	{
		System.out.println("Hola "+nombre);
	}
}