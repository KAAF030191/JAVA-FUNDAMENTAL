package apppolimorfismo;

public class Sumar extends Operacion
{
	public int operar(int x, int y)
	{
		return x+y;
	}
}