package apploops;

public class Main {

	public static void main(String[] args)
	{
		/*for, while, do while*/
		
		String[] nombre={"Kevin", "Arnold"};
		
		for(int i=0;i<2;i++)
		{
			System.out.println(nombre[i]);
		}
		
		String[][] dato= new String[2][2];
		
		dato[0][0]="dato 1";
		dato[0][1]="dato 2";
		dato[1][0]="dato 3";
		dato[1][1]="dato 4";
		
		for(int i=0; i<2; i++)
		{
			for(int j=0; j<2; j++)
			{
				System.out.println(dato[i][j]);
			}
		}
		
		for(int i=0;i<nombre.length;i++)
		{
			System.out.println(nombre[i]);
		}
		
		for(int i=0; i<dato.length; i++)
		{
			for(int j=0; j<dato[i].length; j++)
			{
				System.out.println(dato[i][j]);
			}
		}
		
		for(String item : nombre)
		{
			System.out.println(item);
		}
		
		for(String[] item : dato)
		{
			for(String value : item)
			{
				System.out.println(value);
			}
		}
		
		int x=0;
		
		while(x<5)
		{
			System.out.println("Accedo al while");
			
			x++;//x=x+1;
		}
		
		int y=7;
		
		while(y<7)
		{
			System.out.println("Accedo al segundo while");
			
			y++;
		}
		
		do
		{
			System.out.println("Accedo al do while");
			
			y++;
		}
		while(y<7);
	}
}