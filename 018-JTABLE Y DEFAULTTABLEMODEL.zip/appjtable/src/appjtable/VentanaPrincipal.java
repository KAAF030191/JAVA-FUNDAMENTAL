package appjtable;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaPrincipal {

	private JFrame frame;
	private JTable miTabla;
	private JTable miTabla2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal window = new VentanaPrincipal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VentanaPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 357);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 13, 408, 114);
		frame.getContentPane().add(scrollPane);
		
		miTabla = new JTable();
		miTabla.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null},
				{null, null},
				{null, null},
			},
			new String[] {
				"Columna 1", "Columna 2"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(miTabla);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 152, 408, 95);
		frame.getContentPane().add(scrollPane_1);
		
		miTabla2 = new JTable();
		scrollPane_1.setViewportView(miTabla2);
		
		JButton btnNewButton = new JButton("Generar tabla");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DefaultTableModel defaultTableModel=new DefaultTableModel()
				{
					@Override
					public boolean isCellEditable(int row, int column)
					{
						return false;
					}
				};
				
				defaultTableModel.addColumn("Columna 1");
				defaultTableModel.addColumn("Columna 2");
				defaultTableModel.addColumn("Columna 3");
				defaultTableModel.addColumn("Columna 4");
				
				defaultTableModel.setRowCount(5);
				
				miTabla2.setModel(defaultTableModel);
			}
		});
		btnNewButton.setBounds(265, 260, 155, 25);
		frame.getContentPane().add(btnNewButton);
	}

}
