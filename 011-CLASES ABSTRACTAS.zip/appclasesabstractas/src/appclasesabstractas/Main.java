package appclasesabstractas;

import java.util.Date;

public class Main {

	public static void main(String[] args)
	{
		Persona persona=new Persona();
		
		persona.setNombre("Kevin Arnold");
		persona.setApellido("Arias Figueroa");
		persona.setFechaRegistro(new Date());
		persona.setFechaModificacion(new Date());
		
		System.out.println(persona.getNombre()+" "+persona.getApellido()+" "+persona.getFechaRegistro()+" "+persona.getFechaModificacion());
	}
}