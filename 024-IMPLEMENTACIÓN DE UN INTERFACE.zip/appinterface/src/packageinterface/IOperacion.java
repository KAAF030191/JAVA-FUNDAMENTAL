package packageinterface;

public interface IOperacion
{
	public float sumar(float x, float y);
	public float restar(float x, float y);
	public float multiplicar(float x, float y);
}