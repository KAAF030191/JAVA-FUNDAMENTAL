package appintrowb;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaPrincipal {

	private JFrame frame;
	private JTextField txtNombre;
	private JTextField txtApellido;
	private JTextField txtOtroDato;
	private JTextField txtOtroDatoResutado;
	private JTextField txtApellidoResultado;
	private JTextField txtNombreResultado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal window = new VentanaPrincipal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VentanaPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 290);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(12, 12, 76, 16);
		frame.getContentPane().add(lblNombre);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(100, 10, 320, 22);
		frame.getContentPane().add(txtNombre);
		txtNombre.setColumns(10);
		
		JLabel lblApellido = new JLabel("Apellido");
		lblApellido.setBounds(12, 40, 76, 16);
		frame.getContentPane().add(lblApellido);
		
		JLabel lblOtroDato = new JLabel("Otro dato");
		lblOtroDato.setBounds(12, 68, 76, 16);
		frame.getContentPane().add(lblOtroDato);
		
		txtApellido = new JTextField();
		txtApellido.setColumns(10);
		txtApellido.setBounds(100, 37, 320, 22);
		frame.getContentPane().add(txtApellido);
		
		txtOtroDato = new JTextField();
		txtOtroDato.setColumns(10);
		txtOtroDato.setBounds(100, 65, 320, 22);
		frame.getContentPane().add(txtOtroDato);
		
		JButton btnObtenerDatos = new JButton("Obtener datos");
		btnObtenerDatos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtNombreResultado.setText(txtNombre.getText());
				txtApellidoResultado.setText(txtApellido.getText());
				txtOtroDatoResutado.setText(txtOtroDato.getText());
			}
		});
		btnObtenerDatos.setBounds(285, 100, 135, 25);
		frame.getContentPane().add(btnObtenerDatos);
		
		JLabel label = new JLabel("Nombre");
		label.setBounds(12, 140, 76, 16);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("Apellido");
		label_1.setBounds(12, 168, 76, 16);
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("Otro dato");
		label_2.setBounds(12, 196, 76, 16);
		frame.getContentPane().add(label_2);
		
		txtOtroDatoResutado = new JTextField();
		txtOtroDatoResutado.setEditable(false);
		txtOtroDatoResutado.setColumns(10);
		txtOtroDatoResutado.setBounds(100, 193, 320, 22);
		frame.getContentPane().add(txtOtroDatoResutado);
		
		txtApellidoResultado = new JTextField();
		txtApellidoResultado.setEditable(false);
		txtApellidoResultado.setColumns(10);
		txtApellidoResultado.setBounds(100, 165, 320, 22);
		frame.getContentPane().add(txtApellidoResultado);
		
		txtNombreResultado = new JTextField();
		txtNombreResultado.setEditable(false);
		txtNombreResultado.setColumns(10);
		txtNombreResultado.setBounds(100, 138, 320, 22);
		frame.getContentPane().add(txtNombreResultado);
	}
}
