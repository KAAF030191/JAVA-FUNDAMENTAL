package appherencia;

import java.util.Date;

public class Main {

	public static void main(String[] args)
	{
		Persona persona=new Persona();
		
		persona.setNombre("Kevin Arnold");
		persona.setApellido("Arias Figueroa");
		persona.setEstado(true);
		persona.setFechaRegistro(new Date());
		persona.setFechaModificacion(new Date());
		
		Usuario usuario=new Usuario();
		
		usuario.setNombreUsuario("kaaf030191");
		usuario.setContrasenia("1234567");
		usuario.setEstado(true);
		usuario.setFechaRegistro(new Date());
		usuario.setFechaModificacion(new Date());
		
		System.out.println(persona.getNombre()+" "+persona.getApellido()+" "+persona.isEstado()+" "+persona.getFechaRegistro()+" "+persona.getFechaModificacion());
		
		System.out.println(usuario.getNombreUsuario()+" "+usuario.getContrasenia()+" "+usuario.isEstado()+" "+usuario.getFechaRegistro()+" "+usuario.getFechaModificacion());
	}
}