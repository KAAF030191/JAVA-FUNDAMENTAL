package appsobrecarga;

public class Operacion
{
	public void saludar()
	{
		System.out.println("Hola desde enlawebdekaaf.blogspot.com");
	}
	
	public void saludar(String nombre)
	{
		System.out.println("Hola "+nombre);
	}
	
	public void saludar(String nombre, String lugar)
	{
		System.out.println("Hola "+nombre+" desde "+lugar);
	}
	
	public int Sumar(int x, int y)
	{
		return x+y;
	}
	
	public float Sumar(float x, float y)
	{
		return x+y;
	}
}