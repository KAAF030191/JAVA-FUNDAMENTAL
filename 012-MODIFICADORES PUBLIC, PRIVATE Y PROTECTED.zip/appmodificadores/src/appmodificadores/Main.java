package appmodificadores;

public class Main {

	public static void main(String[] args)
	{
		ClasePadre clasePadre=new ClasePadre();
		
		System.out.println(clasePadre.sumar(7, 4));
		System.out.println(clasePadre.abc());
		System.out.println(clasePadre.consumirPrivado());
		
		ClaseQueHereda claseQueHereda=new ClaseQueHereda();
		
		System.out.println(claseQueHereda.sumar(7, 4));
		System.out.println(claseQueHereda.abc());
		System.out.println(claseQueHereda.consumirPrivado());
		System.out.println(claseQueHereda.consumirProtectedDelPadre());
	}
}