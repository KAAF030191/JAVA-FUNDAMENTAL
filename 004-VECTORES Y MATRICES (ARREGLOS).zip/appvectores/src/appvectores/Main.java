package appvectores;

public class Main {

	public static void main(String[] args)
	{
		String[] nombre=new String[3];
		
		nombre[0]="Nombre 1";
		nombre[1]="Nombre 2";
		nombre[2]="Nombre 3";
		
		nombre[1]="Valor reemplazado";
		
		int[] edad=new int[3];
		
		edad[1]=25;
		edad[0]=23;
		edad[2]=30;
		
		
		System.out.println(nombre[1]+"---"+edad[1]);
		
		String[][] dato=new String[2][3];
		
		dato[0][0]="Dato 0,0";
		dato[0][1]="Dato 0,1";
		dato[0][2]="Dato 0,2";
		
		dato[1][0]="Dato 1,0";
		dato[1][1]="Dato 2,1";
		dato[1][2]="Dato 3,2";
		
		System.out.println(dato[0][1]);
		
		String[][][][] matriz=new String[2][3][2][4];
		
		matriz[0][2][1][2]="Valor de la matriz 0,2,1,2";
		
		System.out.println(matriz[0][2][1][2]);
	}
}