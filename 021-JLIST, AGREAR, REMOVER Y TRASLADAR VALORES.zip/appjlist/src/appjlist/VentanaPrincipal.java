package appjlist;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ListSelectionModel;

public class VentanaPrincipal {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal window = new VentanaPrincipal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VentanaPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane1 = new JScrollPane();
		scrollPane1.setBounds(12, 51, 134, 189);
		frame.getContentPane().add(scrollPane1);
		
		JList<String> jList1 = new JList<String>();
		jList1.setModel(new DefaultListModel<String>());
		scrollPane1.setViewportView(jList1);
		
		JScrollPane scrollPane2 = new JScrollPane();
		scrollPane2.setBounds(286, 13, 134, 189);
		frame.getContentPane().add(scrollPane2);
		
		JList<String> jList2 = new JList<String>();
		jList2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		jList2.setModel(new DefaultListModel<String>());
		scrollPane2.setViewportView(jList2);
		
		JButton btnCargarDatos = new JButton("Cargar datos");
		btnCargarDatos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DefaultListModel<String> defaultListModel=((DefaultListModel<String>)jList1.getModel());
				
				defaultListModel.addElement("Elemento 1");
				defaultListModel.addElement("Elemento 2");
				defaultListModel.addElement("Elemento 3");
				defaultListModel.addElement("Elemento 4");
				defaultListModel.addElement("Elemento 5");
				defaultListModel.addElement("Elemento 6");
				defaultListModel.addElement("Elemento 7");
			}
		});
		btnCargarDatos.setBounds(12, 11, 134, 25);
		frame.getContentPane().add(btnCargarDatos);
		
		JButton btnMigrar = new JButton(">");
		btnMigrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultListModel<String> defaultListModel1=((DefaultListModel<String>)jList1.getModel());
				DefaultListModel<String> defaultListModel2=((DefaultListModel<String>)jList2.getModel());
				
				for(int item : jList1.getSelectedIndices())
				{
					defaultListModel2.addElement(defaultListModel1.getElementAt(item));
				}
			}
		});
		btnMigrar.setBounds(158, 111, 116, 25);
		frame.getContentPane().add(btnMigrar);
		
		JButton btnRemover = new JButton("Remover");
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(jList2.getSelectedIndex()>=0)
				{
					DefaultListModel<String> defaultListModel2=((DefaultListModel<String>)jList2.getModel());
					
					defaultListModel2.remove(jList2.getSelectedIndex());
				}
			}
		});
		btnRemover.setBounds(286, 215, 134, 25);
		frame.getContentPane().add(btnRemover);
	}
}
