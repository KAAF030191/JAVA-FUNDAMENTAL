package apppolimorfismo;

public class Multiplicar extends Operacion
{
	public int operar(int x, int y)
	{
		return x*y;
	}
}