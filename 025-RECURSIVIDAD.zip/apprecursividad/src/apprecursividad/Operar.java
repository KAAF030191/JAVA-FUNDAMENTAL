package apprecursividad;

public class Operar
{
	public int sumarNumeros(int x)
	{
		if(x==1)
		{
			return 1;
		}
		
		return x+sumarNumeros(x-1);
		/*
		 sumarNumeros(4);
		 4+sumarNumeros(3);4+6
		 3+sumarNumeros(2);3+3
		 2+sumarNumeros(1);2+1
		 */
	}
}