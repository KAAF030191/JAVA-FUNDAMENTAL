package appmetodosfunciones;

public class Main {

	public static void main(String[] args) 
	{
		int x=7;
		int y=4;
		
		Main miClase=new Main();
		
		miClase.sumar(x, y);
		miClase.sumar(10, 5);
		
		System.out.println("La resta es: "+miClase.restar(x,  y));
	}
	
	public void sumar(int variable1, int variable2)
	{
		int resultado=variable1+variable2;
		
		System.out.println("La suma es : "+resultado);
	}
	
	public int restar(int variable1, int variable2)
	{
		int resultado=variable1-variable2;
		
		return resultado;
	}
}