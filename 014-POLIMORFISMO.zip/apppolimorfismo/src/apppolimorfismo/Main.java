package apppolimorfismo;

public class Main {

	public static void main(String[] args)
	{
		Operacion operacion0, operacion1, operacion2, operacion3;
		
		operacion0=new Operacion();
		operacion1=new Sumar();
		operacion2=new Restar();
		operacion3=new Multiplicar();
		
		System.out.println(operacion0.operar(7, 4));
		System.out.println(operacion1.operar(7, 4));
		System.out.println(operacion2.operar(7, 4));
		System.out.println(operacion3.operar(7, 4));
	}
}