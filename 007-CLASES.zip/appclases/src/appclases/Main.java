package appclases;

public class Main {

	public static void main(String[] args)
	{
		int x=7;
		int y=4;
		
		OperacionMatematica operacionMatematica=new OperacionMatematica();
		
		System.out.println("La suma es: "+operacionMatematica.Operar(x, y, "suma"));
		System.out.println("La resta es: "+operacionMatematica.Operar(x, y, "resta"));
		System.out.println("La multiplicaci�n es: "+operacionMatematica.Operar(x, y, "multiplicacion"));
		System.out.println("La divisi�n es: "+operacionMatematica.Operar(x, y, "division"));
		System.out.println("La raiz cuadrada es: "+operacionMatematica.Operar(x, y, "raizcuadrada"));
		
		operacionMatematica.Hola();
	}
}