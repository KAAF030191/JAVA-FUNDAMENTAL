package appcondicionales;

public class Main {

	public static void main(String[] args)
	{
		int x=10;
		
		//>, <, ==, >=, <=, !, %
		
		if(x>15)
		{
			System.out.println("Se accedi� al if 1");
		}
		else
		{
			System.out.println("Se accedi� al else 1");
		}
		
		if(x<15)
		{
			System.out.println("Se accedi� al if 2");
		}
		else
		{
			System.out.println("Se accedi� al else 2");
		}
		
		if(x>10)
		{
			System.out.println("Se accedi� al if 3");
		}
		else
		{
			System.out.println("Se accedi� al else 3");
		}
		
		if(x<10)
		{
			System.out.println("Se accedi� al if 4");
		}
		else
		{
			System.out.println("Se accedi� al else 4");
		}
		
		if(x==10)
		{
			System.out.println("Se accedi� al if 5");
		}
		else
		{
			System.out.println("Se accedi� al else 5");
		}
		
		if(x>=10)
		{
			System.out.println("Se accedi� al if 6");
		}
		else
		{
			System.out.println("Se accedi� al else 6");
		}
		
		if(x<=10)
		{
			System.out.println("Se accedi� al if 7");
		}
		else
		{
			System.out.println("Se accedi� al else 7");
		}
		
		if(!(x>15))
		{
			System.out.println("Se accedi� al if 8");
		}
		else
		{
			System.out.println("Se accedi� al else 8");
		}
		
		if((x%5)==0)
		{
			System.out.println("Se accedi� al if 9");
		}
		else
		{
			System.out.println("Se accedi� al else 9");
		}
		
		if((x%3)==0)
		{
			System.out.println("Se accedi� al if 10");
		}
		else
		{
			System.out.println("Se accedi� al else 10");
		}
		
		/*----------------------------------------------*/
		
		String nombre="Kevin";
		int edad=20;
		String documentoIdentidad="12345678";
		
		if(nombre.equals("Kevin") && edad==25 && documentoIdentidad.equals("12345678"))
		{
			System.out.println("Se accedi� al if 11");
		}
		
		if(nombre.equals("Kevin") || edad==25)
		{
			System.out.println("Se accedi� al if 12");
		}
		
		if(nombre.equals("Kevin") && (edad==25 || documentoIdentidad.equals("12345678")))
		{
			System.out.println("Se accedi� al if 13");
		}
		
		/*----------------------------------------------*/
		
		boolean sexo=true;
		String cadenaSexo;
		
		if(sexo)
		{
			cadenaSexo="Masculino";
		}
		else
		{
			cadenaSexo="Femenino";
		}
		
		System.out.println("El sexo de la persona es: "+cadenaSexo);
		
		//((Condici�n) ? "Si se cumple" : "Si no se cumple");
		
		System.out.println("El sexo de la persona es: "+((sexo) ? "Maculino" : "Femenino"));
		
		int tipoUsuario=1;/*1->Cliente, 2->Usuario normal, 3->Administrador*/
		
		String tipoUsuarioCadena=tipoUsuario==1 ? "Cliente" : (tipoUsuario==2 ? "Usuario normal" : tipoUsuario==3 ? "Administrador" : "No especificado");
		
		System.out.println(tipoUsuarioCadena);
		
		String tipoUsuarioCadena2;
		
		if(tipoUsuario==1)
		{
			tipoUsuarioCadena2="Cliente";
		}
		else
		{
			if(tipoUsuario==2)
			{
				tipoUsuarioCadena2="Usuario normal";
			}
			else
			{
				if(tipoUsuario==3)
				{
					tipoUsuarioCadena2="Administrador";
				}
				else
				{
					tipoUsuarioCadena2="No especificado";
				}
			}
		}
		
		System.out.println(tipoUsuarioCadena2);
	}

}