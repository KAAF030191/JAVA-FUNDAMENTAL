package appmodificadores;

public class ClaseQueHereda extends ClasePadre
{
	public int consumirProtectedDelPadre()
	{
		return abc();
	}
}
