package appjslider;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class VentanaPrincipal {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal window = new VentanaPrincipal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VentanaPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 201);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblBlog = new JLabel("enlawebdekaaf.blogspot.com");
		lblBlog.setFont(new Font("Arial", Font.PLAIN, 13));
		lblBlog.setBounds(12, 52, 408, 39);
		frame.getContentPane().add(lblBlog);
		
		JSlider miSlider = new JSlider();
		miSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				lblBlog.setFont(new Font("Arial", 0, miSlider.getValue()));
			}
		});
		miSlider.setValue(13);
		miSlider.setMinimum(10);
		miSlider.setMaximum(22);
		miSlider.setBounds(12, 13, 408, 26);
		frame.getContentPane().add(miSlider);
	}

}
