package apptiposdedatos;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

	public static void main(String[] args)
	{
		String nombre;
		int edad;
		float estatura;
		boolean sexo;
		double peso;
		
		nombre="Kevin Arnold";
		edad=25;
		estatura=1.70f;
		sexo=true;
		peso=74.5;
		
		System.out.println(nombre+" "+edad+" "+estatura+" "+sexo+" "+peso);
		
		/*---------------------------------------------------------------------*/
		
		Date fechaActual;
		
		fechaActual=new Date();
		
		System.out.println(fechaActual);
		
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		
		String fecha=sdf.format(fechaActual);
		
		System.out.println(fecha);
		
		/*---------------------------------------------------------------------*/
		
		float x=0.7f;
		
		System.out.println(x+x+x+x+x+x+x);
		
		BigDecimal y=new BigDecimal("0.7");
		
		System.out.println(y.add(y).add(y).add(y).add(y).add(y).add(y));
	}
}