package apprecursividad;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import de.javasoft.plaf.synthetica.SyntheticaBlackEyeLookAndFeel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ventana extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtCantidad;
	private JTextField txtResulado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try 
				{
					UIManager.setLookAndFeel(new SyntheticaBlackEyeLookAndFeel());
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
				try {
					Ventana frame = new Ventana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 210);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSumatorioDeLos = new JLabel("Sumatorio de los primeros N n\u00FAmeros");
		lblSumatorioDeLos.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblSumatorioDeLos.setBounds(12, 13, 408, 40);
		contentPane.add(lblSumatorioDeLos);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 66, 408, 2);
		contentPane.add(separator);
		
		JLabel lblCantidad = new JLabel("Cantidad");
		lblCantidad.setBounds(12, 81, 86, 16);
		contentPane.add(lblCantidad);
		
		txtCantidad = new JTextField();
		txtCantidad.setBounds(110, 78, 184, 22);
		contentPane.add(txtCantidad);
		txtCantidad.setColumns(10);
		
		JButton btnCalcular = new JButton("Calcular");
		btnCalcular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int cantidadNumeros=Integer.parseInt(txtCantidad.getText());
				
				int resultado=(new Operar()).sumarNumeros(cantidadNumeros);
				
				txtResulado.setText(String.valueOf(resultado));
			}
		});
		btnCalcular.setBounds(306, 77, 114, 25);
		contentPane.add(btnCalcular);
		
		JLabel lblLaSumaEs = new JLabel("La suma es");
		lblLaSumaEs.setBounds(12, 129, 86, 16);
		contentPane.add(lblLaSumaEs);
		
		txtResulado = new JTextField();
		txtResulado.setEditable(false);
		txtResulado.setBounds(110, 126, 184, 22);
		contentPane.add(txtResulado);
		txtResulado.setColumns(10);
	}
}
