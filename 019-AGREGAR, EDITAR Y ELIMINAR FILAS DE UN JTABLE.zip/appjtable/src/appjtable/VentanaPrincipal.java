package appjtable;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ListSelectionModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class VentanaPrincipal {

	private JFrame frame;
	private JTable miTabla;
	private JTextField txtNombre;
	private JTextField txtApellido;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal window = new VentanaPrincipal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VentanaPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 378);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 85, 408, 195);
		frame.getContentPane().add(scrollPane);
		
		miTabla = new JTable();
		miTabla.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent arg0) {
				if(miTabla.getSelectedRow()>=0)
				{
					txtNombre.setText(miTabla.getValueAt(miTabla.getSelectedRow(), 0).toString());
					txtApellido.setText(miTabla.getValueAt(miTabla.getSelectedRow(), 1).toString());
				}
			}
		});
		miTabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		miTabla.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nombre", "Apellido"
			}
		));
		scrollPane.setViewportView(miTabla);
		
		JButton btnAgregar = new JButton("Agregar");
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Object[] row={txtNombre.getText(), txtApellido.getText()};
				
				((DefaultTableModel)miTabla.getModel()).addRow(row);
			}
		});
		btnAgregar.setBounds(323, 293, 97, 25);
		frame.getContentPane().add(btnAgregar);
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(miTabla.getSelectedRow()>=0)
				{
					miTabla.setValueAt(txtNombre.getText(), miTabla.getSelectedRow(), 0);
					miTabla.setValueAt(txtApellido.getText(), miTabla.getSelectedRow(), 1);
				}
			}
		});
		btnEditar.setBounds(214, 293, 97, 25);
		frame.getContentPane().add(btnEditar);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(miTabla.getSelectedRow()>=0)
				{
					((DefaultTableModel)miTabla.getModel()).removeRow(miTabla.getSelectedRow());
				}
			}
		});
		btnEliminar.setBounds(105, 293, 97, 25);
		frame.getContentPane().add(btnEliminar);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(12, 13, 56, 16);
		frame.getContentPane().add(lblNombre);
		
		JLabel lblApellido = new JLabel("Apellido");
		lblApellido.setBounds(12, 53, 56, 16);
		frame.getContentPane().add(lblApellido);
		
		txtNombre = new JTextField();
		txtNombre.setBounds(80, 10, 340, 22);
		frame.getContentPane().add(txtNombre);
		txtNombre.setColumns(10);
		
		txtApellido = new JTextField();
		txtApellido.setColumns(10);
		txtApellido.setBounds(80, 50, 340, 22);
		frame.getContentPane().add(txtApellido);
	}
}
