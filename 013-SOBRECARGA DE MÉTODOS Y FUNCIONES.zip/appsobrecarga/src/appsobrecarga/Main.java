package appsobrecarga;

public class Main {

	public static void main(String[] args)
	{
		Operacion operacion=new Operacion();
		
		operacion.saludar();
		
		operacion.saludar("Kevin Arnold");
		
		operacion.saludar("Kevin Arnold", "enlawebdekaaf.blogspot.com");
		
		System.out.println(operacion.Sumar(7, 4));
		System.out.println(operacion.Sumar(7f, 4.5f));
	}
}