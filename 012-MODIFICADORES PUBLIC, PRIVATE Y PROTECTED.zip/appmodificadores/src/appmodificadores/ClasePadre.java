package appmodificadores;

public class ClasePadre
{
	public int sumar(int x, int y)
	{
		return x+y;
	}
	
	private int xyz()
	{
		return 7;
	}
	
	protected int abc()
	{
		return 10;
	}
	
	public int consumirPrivado()
	{
		return xyz();
	}
}