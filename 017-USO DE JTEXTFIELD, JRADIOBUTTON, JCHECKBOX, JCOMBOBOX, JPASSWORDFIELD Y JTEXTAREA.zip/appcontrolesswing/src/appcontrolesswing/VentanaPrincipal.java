package appcontrolesswing;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Enumeration;
import javax.swing.JTextArea;

public class VentanaPrincipal {

	private JFrame frame;
	private JTextField txtNombreCompleto;
	private JPasswordField passContrasenia;
	private JTextField txtNombreCompletoResultado;
	private JTextField txtSexoResultado;
	private JTextField txtLenguajeFavoritoResultado;
	private JTextField txtPaisResultado;
	private JTextField txtContraseniaResultado;
	private final ButtonGroup radioGroupSexo = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal window = new VentanaPrincipal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VentanaPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 755);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNombreCompleto = new JLabel("Nombre completo");
		lblNombreCompleto.setBounds(12, 22, 119, 16);
		frame.getContentPane().add(lblNombreCompleto);
		
		JLabel lblSexo = new JLabel("Sexo");
		lblSexo.setBounds(12, 60, 119, 16);
		frame.getContentPane().add(lblSexo);
		
		JLabel lblLenguajesFavoritos = new JLabel("Lenguajes fav.");
		lblLenguajesFavoritos.setBounds(12, 98, 119, 16);
		frame.getContentPane().add(lblLenguajesFavoritos);
		
		JLabel lblPais = new JLabel("Pa\u00EDs");
		lblPais.setBounds(12, 136, 119, 16);
		frame.getContentPane().add(lblPais);
		
		JLabel lblContrasenia = new JLabel("Contrase\u00F1a");
		lblContrasenia.setBounds(12, 174, 119, 16);
		frame.getContentPane().add(lblContrasenia);
		
		txtNombreCompleto = new JTextField();
		txtNombreCompleto.setBounds(143, 19, 277, 22);
		frame.getContentPane().add(txtNombreCompleto);
		txtNombreCompleto.setColumns(10);
		
		JRadioButton radioMasculino = new JRadioButton("Masculino");
		radioGroupSexo.add(radioMasculino);
		radioMasculino.setSelected(true);
		radioMasculino.setBounds(143, 56, 92, 25);
		frame.getContentPane().add(radioMasculino);
		
		JRadioButton radioFemenino = new JRadioButton("Femenino");
		radioGroupSexo.add(radioFemenino);
		radioFemenino.setBounds(238, 56, 92, 25);
		frame.getContentPane().add(radioFemenino);
		
		JCheckBox chbCSharp = new JCheckBox("C#");
		chbCSharp.setBounds(143, 94, 51, 25);
		frame.getContentPane().add(chbCSharp);
		
		JCheckBox chbJava = new JCheckBox("Java");
		chbJava.setBounds(198, 94, 64, 25);
		frame.getContentPane().add(chbJava);
		
		JCheckBox chbRuby = new JCheckBox("Ruby");
		chbRuby.setBounds(266, 94, 64, 25);
		frame.getContentPane().add(chbRuby);
		
		JComboBox cbPais = new JComboBox();
		cbPais.setModel(new DefaultComboBoxModel(new String[] {"Per\u00FA", "M\u00E9xico", "Colombia", "Ecuador", "Chile", "Bolivia"}));
		cbPais.setBounds(143, 133, 277, 22);
		frame.getContentPane().add(cbPais);
		
		passContrasenia = new JPasswordField();
		passContrasenia.setBounds(143, 171, 277, 22);
		frame.getContentPane().add(passContrasenia);
		
		JLabel lblNombreCompletoResultado = new JLabel("Nombre completo");
		lblNombreCompletoResultado.setBounds(12, 394, 119, 16);
		frame.getContentPane().add(lblNombreCompletoResultado);
		
		JLabel lblSexoResultado = new JLabel("Sexo");
		lblSexoResultado.setBounds(12, 432, 119, 16);
		frame.getContentPane().add(lblSexoResultado);
		
		JLabel lblLenguajeFavoritoResultado = new JLabel("Lenguajes fav.");
		lblLenguajeFavoritoResultado.setBounds(12, 470, 119, 16);
		frame.getContentPane().add(lblLenguajeFavoritoResultado);
		
		JLabel lblPaisResultado = new JLabel("Pa\u00EDs");
		lblPaisResultado.setBounds(12, 508, 119, 16);
		frame.getContentPane().add(lblPaisResultado);
		
		JLabel lblContraseniaResultado = new JLabel("Contrase\u00F1a");
		lblContraseniaResultado.setBounds(12, 546, 119, 16);
		frame.getContentPane().add(lblContraseniaResultado);
		
		txtNombreCompletoResultado = new JTextField();
		txtNombreCompletoResultado.setEditable(false);
		txtNombreCompletoResultado.setColumns(10);
		txtNombreCompletoResultado.setBounds(143, 391, 277, 22);
		frame.getContentPane().add(txtNombreCompletoResultado);
		
		txtSexoResultado = new JTextField();
		txtSexoResultado.setEditable(false);
		txtSexoResultado.setColumns(10);
		txtSexoResultado.setBounds(143, 429, 277, 22);
		frame.getContentPane().add(txtSexoResultado);
		
		txtLenguajeFavoritoResultado = new JTextField();
		txtLenguajeFavoritoResultado.setEditable(false);
		txtLenguajeFavoritoResultado.setColumns(10);
		txtLenguajeFavoritoResultado.setBounds(143, 467, 277, 22);
		frame.getContentPane().add(txtLenguajeFavoritoResultado);
		
		txtPaisResultado = new JTextField();
		txtPaisResultado.setEditable(false);
		txtPaisResultado.setColumns(10);
		txtPaisResultado.setBounds(143, 505, 277, 22);
		frame.getContentPane().add(txtPaisResultado);
		
		txtContraseniaResultado = new JTextField();
		txtContraseniaResultado.setEditable(false);
		txtContraseniaResultado.setColumns(10);
		txtContraseniaResultado.setBounds(143, 543, 277, 22);
		frame.getContentPane().add(txtContraseniaResultado);
		
		JTextArea txtDescripcion = new JTextArea();
		txtDescripcion.setBounds(143, 217, 277, 66);
		frame.getContentPane().add(txtDescripcion);
		
		JLabel lblDescripcion = new JLabel("Descripci\u00F3n");
		lblDescripcion.setBounds(12, 244, 119, 16);
		frame.getContentPane().add(lblDescripcion);
		
		JLabel lblDescripcin = new JLabel("Descripci\u00F3n");
		lblDescripcin.setBounds(12, 624, 119, 16);
		frame.getContentPane().add(lblDescripcin);
		
		JTextArea txtDescripcionResultado = new JTextArea();
		txtDescripcionResultado.setEditable(false);
		txtDescripcionResultado.setBounds(143, 578, 277, 92);
		frame.getContentPane().add(txtDescripcionResultado);
		
		JButton btnObtenerDatos = new JButton("Obtener datos");
		btnObtenerDatos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				txtNombreCompletoResultado.setText(txtNombreCompleto.getText());
				
				Enumeration<AbstractButton> radioSexo=radioGroupSexo.getElements();
				
				while (radioSexo.hasMoreElements())
				{
					AbstractButton radioTemporal = (AbstractButton) radioSexo.nextElement();
					
					if(radioTemporal.isSelected())
					{
						txtSexoResultado.setText(radioTemporal.getText());
						
						break;
					}
				}
				
				String lenguajesFavoritos="";
				
				lenguajesFavoritos+=(chbCSharp.isSelected() ? chbCSharp.getText() : "");
				lenguajesFavoritos+=(chbJava.isSelected() ? ","+chbJava.getText() : "");
				lenguajesFavoritos+=(chbRuby.isSelected() ? ","+chbRuby.getText() : "");
				
				txtLenguajeFavoritoResultado.setText(lenguajesFavoritos);
				
				txtPaisResultado.setText(cbPais.getSelectedItem().toString());
				
				txtContraseniaResultado.setText(passContrasenia.getText());
				
				txtDescripcionResultado.setText(txtDescripcion.getText());
			}
		});
		btnObtenerDatos.setBounds(279, 310, 141, 25);
		frame.getContentPane().add(btnObtenerDatos);
	}
}
