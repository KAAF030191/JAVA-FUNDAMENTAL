package appencapsulamiento;

public class Main {

	public static void main(String[] args)
	{
		Persona persona=new Persona();
		
		persona.setNombre("Kevin Arnold");
		persona.setApellido("Arias Figueroa");
		persona.setSexo(true);
		
		System.out.println("Nombre: "+persona.getNombre());
		System.out.println("Apellido: "+persona.getApellido());
		System.out.println("Sexo: "+(persona.isSexo() ? "Masculino" : "Femenino"));
	}
}