package appinterface;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import clases.Operacion;
import de.javasoft.plaf.synthetica.SyntheticaBlackEyeLookAndFeel;
import packageinterface.IOperacion;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ventana extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNumero1;
	private JTextField txtNumero2;
	private JTextField txtResutado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try 
				{
					UIManager.setLookAndFeel(new SyntheticaBlackEyeLookAndFeel());
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
				try {
					Ventana frame = new Ventana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 288, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNmero = new JLabel("N\u00FAmero 1");
		lblNmero.setBounds(12, 28, 75, 16);
		contentPane.add(lblNmero);
		
		JLabel lblNmero_1 = new JLabel("N\u00FAmero 2");
		lblNmero_1.setBounds(12, 66, 75, 16);
		contentPane.add(lblNmero_1);
		
		txtNumero1 = new JTextField();
		txtNumero1.setBounds(99, 25, 155, 22);
		contentPane.add(txtNumero1);
		txtNumero1.setColumns(10);
		
		txtNumero2 = new JTextField();
		txtNumero2.setColumns(10);
		txtNumero2.setBounds(99, 63, 155, 22);
		contentPane.add(txtNumero2);
		
		JButton btnSumar = new JButton("Sumar");
		btnSumar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IOperacion iOperacion=new Operacion();
				
				float numero1, numero2, resultado;
				
				numero1=Float.parseFloat(txtNumero1.getText());
				numero2=Float.parseFloat(txtNumero2.getText());
				
				resultado=iOperacion.sumar(numero1, numero2);
				
				txtResutado.setText(String.valueOf(resultado));
			}
		});
		btnSumar.setBounds(157, 98, 97, 37);
		contentPane.add(btnSumar);
		
		JButton btnRestar = new JButton("Restar");
		btnRestar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				IOperacion iOperacion=new Operacion();
				
				float numero1, numero2, resultado;
				
				numero1=Float.parseFloat(txtNumero1.getText());
				numero2=Float.parseFloat(txtNumero2.getText());
				
				resultado=iOperacion.restar(numero1, numero2);
				
				txtResutado.setText(String.valueOf(resultado));
			}
		});
		btnRestar.setBounds(157, 148, 97, 37);
		contentPane.add(btnRestar);
		
		JButton btnMultiplciar = new JButton("Multiplicar");
		btnMultiplciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IOperacion iOperacion=new Operacion();
				
				float numero1, numero2, resultado;
				
				numero1=Float.parseFloat(txtNumero1.getText());
				numero2=Float.parseFloat(txtNumero2.getText());
				
				resultado=iOperacion.multiplicar(numero1, numero2);
				
				txtResutado.setText(String.valueOf(resultado));
			}
		});
		btnMultiplciar.setBounds(157, 198, 97, 37);
		contentPane.add(btnMultiplciar);
		
		JLabel lblResultado = new JLabel("Resultado");
		lblResultado.setBounds(12, 134, 75, 16);
		contentPane.add(lblResultado);
		
		txtResutado = new JTextField();
		txtResutado.setBounds(12, 163, 133, 22);
		contentPane.add(txtResutado);
		txtResutado.setColumns(10);
	}
}
