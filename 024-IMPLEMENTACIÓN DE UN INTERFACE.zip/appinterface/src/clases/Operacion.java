package clases;

import packageinterface.IOperacion;

public class Operacion implements IOperacion
{

	@Override
	public float sumar(float x, float y) {
		return x+y;
	}

	@Override
	public float restar(float x, float y) {
		return x-y;
	}

	@Override
	public float multiplicar(float x, float y) {
		return x*y;
	}
}