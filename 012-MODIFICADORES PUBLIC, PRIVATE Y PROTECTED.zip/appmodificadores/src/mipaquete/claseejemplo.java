package mipaquete;

import appmodificadores.ClasePadre;
import appmodificadores.ClaseQueHereda;

public class claseejemplo
{
	public static void main(String[] args)
	{
		ClaseQueHereda claseQueHereda=new ClaseQueHereda();
		
		System.out.println(claseQueHereda.sumar(7, 4));
		System.out.println(claseQueHereda.consumirPrivado());
		System.out.println(claseQueHereda.consumirProtectedDelPadre());
		
		ClasePadre clasePadre=new ClasePadre();
		
		System.out.println(clasePadre.sumar(7, 4));
		System.out.println(clasePadre.consumirPrivado());
	}
}