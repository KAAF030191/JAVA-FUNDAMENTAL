package apppolimorfismo;

public class Operacion
{
	public int operar(int x, int y)
	{
		return (int)(x/y);
	}
}